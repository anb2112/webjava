/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import java.sql.*;

/**
 *
 * @author laboratorio
 */
public class UserDAO {
    public static boolean login(String user, String password) {
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = Database.getConnection();
            ps = con.prepareStatement(
                "select user, pass from userinfo where user= ? and pass= ?");
            ps.setString(1, user);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println(rs.getString("user"));
                return true;
            }
            else {
                return false;
            }
        }catch (Exception ex) {
            System.out.println("Erro no login() -->" + ex.getMessage());
            return false;
            
        } finally {
            Database.close(con);
        }
    }
}
